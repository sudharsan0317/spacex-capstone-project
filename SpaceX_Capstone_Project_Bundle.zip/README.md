# SpaceX Falcon 9 Landing Analysis

This educational project uses `Spacex.csv` to explore landing outcome labels and compare two baseline classification models.

## Files
- `Spacex.csv`: supplied dataset used for this analysis
- `SpaceX_Capstone_Expanded_Report.pdf`: report with EDA, SQL findings, model results, map/dashboard notes
- `spacex_launch_sites_map.html`: interactive Folium map
- `spacex_dashboard.py`: Dash app source
- `sql_queries_and_results.txt`: SQL query text and result tables
- `sql_*.csv`: individual SQL result tables
- `dashboard_preview.png`: static preview of dashboard-style charts

## Run the dashboard
Install dependencies: `pip install dash plotly pandas`
Place `spacex_dashboard.py` and `Spacex.csv` in the same folder, then run:
`python spacex_dashboard.py`

## Important
The binary label is 1 when `Landing_Outcome` starts with `Success`; all other labels are grouped as 0. This is a simplifying analytical choice, not a claim that all non-success labels mean the same thing. Model metrics are preliminary and based on a single stratified holdout split of a small dataset. This project bundle does not claim completion of every original IBM course lab.
